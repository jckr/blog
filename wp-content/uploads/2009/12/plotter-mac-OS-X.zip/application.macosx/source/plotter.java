import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class plotter extends PApplet {

public void setup(){
size(410,320);
Chart myChart = new Chart(loadStrings("mychart.txt"));
myChart.display();
save("mychart.png");
}
public void draw(){}


class DimAxis{
  String[] labels;
  PFont font;
  int nbValues;
  AxisStyle style;
  
  DimAxis(String[] myLabels) {
    labels = myLabels;
    nbValues = labels.length;
    font = createFont("Frutiger",10,true);
    style= new AxisStyle();
  }


  DimAxis(String[] myLabels, String fontName, float fontSize) {
    labels = myLabels;
    nbValues = labels.length;
    font = createFont(fontName,fontSize,true);
    style= new AxisStyle();
  }
}

class ValAxis{
  float minVal, maxVal, step;
  boolean hasTitle = false;
  String title;
  PFont font;
  AxisStyle style;
  
  ValAxis(float myMax, float myStep) {
    minVal = 0;
    maxVal = myMax;
    step = myStep;
    font = createFont("Verdana",9,true);
    style= new AxisStyle(false);
  }

  ValAxis(float myMax, float myStep, String fontName, float fontSize) {
    minVal = 0;
    maxVal = myMax;
    step = myStep;
    font = createFont(fontName,fontSize,true);
    style= new AxisStyle(false);
  }

  ValAxis(float myMin, float myMax, float myStep) {
    minVal = myMin;
    maxVal = myMax;
    step = myStep;
    font = createFont("verdana",9,true);
    style= new AxisStyle(false);
  }

  ValAxis(float myMin, float myMax, float myStep, String fontName, float fontSize) {
    minVal = myMin;
    maxVal = myMax;
    step = myStep;
    font = createFont(fontName,fontSize,true);
    style= new AxisStyle(false);
  }

  ValAxis(float[][] myValues) {
    float seriesMin, seriesMax, absMax;
    seriesMin=myValues[0][0];
    seriesMax=myValues[0][0];
    for(int i=0;i<myValues.length;i++){
      seriesMin=min(seriesMin, min(myValues[i]));
      seriesMax=max(seriesMax, max(myValues[i]));
    }
    
    absMax = max(abs(seriesMin), abs(seriesMax));

    if(seriesMin>=0) {
      minVal=0;
      maxVal=pow(10,ceil(log(seriesMax)/log(10)));
      if (seriesMax<.5f*maxVal) {
        maxVal=.5f*maxVal;
      }
      if (seriesMax<.4f*maxVal) {
        maxVal=.4f*maxVal;
      }
    } 
    else {
      maxVal=pow(10,ceil(log(absMax)/log(10)));
      if (absMax<.5f*maxVal) {
        maxVal=.5f*maxVal;
      }
      if (absMax<.4f*maxVal) {
        maxVal=.4f*maxVal;
      }
      minVal = -maxVal;
    }
    step = maxVal/4;
    font = createFont("Verdana",9,true);
    style= new AxisStyle(false);
  }
  ValAxis(float[][] myValues, String fontName, float fontSize) {
       float seriesMin, seriesMax, absMax;
    seriesMin=myValues[0][0];
    seriesMax=myValues[0][0];
    for(int i=0;i<myValues.length;i++){
      seriesMin=min(seriesMin, min(myValues[i]));
      seriesMax=max(seriesMax, max(myValues[i]));
    }
    
    absMax = max(abs(seriesMin), abs(seriesMax));

    if(seriesMin>=0) {
      minVal=0;
      maxVal=pow(10,ceil(log(seriesMax)/log(10)));
      if (seriesMax<.5f*maxVal) {
        maxVal=.5f*maxVal;
      }
      if (seriesMax<.4f*maxVal) {
        maxVal=.4f*maxVal;
      }
    } 
    else {
      maxVal=pow(10,ceil(log(absMax)/log(10)));
      if (absMax<.5f*maxVal) {
        maxVal=.5f*maxVal;
      }
      if (absMax<.4f*maxVal) {
        maxVal=.4f*maxVal;
      }
      minVal = -maxVal;
    }
    step = maxVal/4;
    font = createFont(fontName,fontSize,true);
    style= new AxisStyle(false);
  }
  public int rounding(){
    if (PApplet.parseInt(step)==step) {
      return 0;
    }
    else if (PApplet.parseInt(10*step)==10*step) {
      return 1;
    }
    else {
      return 2;
    }
  }
}


class Chart{
  int seriesNb;
  Series[] series= new Series[10];
  DimAxis dimAxis;
  ValAxis valAxis;
  ValAxis valAxis2;
  Boolean has2Axes = false;
  String title;
  String subtitle;
  String source;
  ChartStyle style;
  String[] label = new String[10];
  float[] labelX = new float[10];
  float[] labelY = new float[10];
  int labelNb;
  /*
  Simplified constructors 
  */
  Chart(float[][] myValues, String[] myLabels, String[] mySeriesNames, String myTitle, String myMode){
    title=myTitle;subtitle="";source="";
    init(myValues, myLabels, mySeriesNames, myMode);
  }
  
  Chart(float[][] myValues, String[] myLabels, String[] mySeriesNames, String myTitle, String mySubtitle, String myMode){
    title=myTitle;subtitle=mySubtitle;source="";
    init(myValues, myLabels, mySeriesNames, myMode);
  }
  
  Chart(float[][] myValues, String[] myLabels, String[] mySeriesNames, String myTitle, String mySubtitle, String mySource, String myMode){
    title=myTitle;subtitle=mySubtitle;source=mySource;
    init(myValues, myLabels, mySeriesNames, myMode);
  }
  
  public void init(float[][] myValues, String[] myLabels, String[] mySeriesNames, String myMode){
    int labelFontSize = 7;
    String labelFont = "Verdana";
    if (myMode.equals("DEFAULT")){
      labelFontSize=8;
    }
    seriesNb = min(myValues.length,10);
    for(int i=0;i<seriesNb;i++){
      println("all going well "+i);
      series[i]= new Series(myValues[i],mySeriesNames[i],i);
    }

    style=new ChartStyle(myMode);
    dimAxis = new DimAxis(myLabels, labelFont, PApplet.parseInt(style.chartHeight/32));
    valAxis = new ValAxis(myValues, labelFont, PApplet.parseInt(style.chartHeight/32));
    style.updateSize(this);
  }
    
  /*
  Full constructor
  */
  Chart(String[] dataFile){
    boolean debug=false;
    String[] myLabels = new String[1000];  
    String[] mySeriesNames = new String[10];
    float[][] myValues = new float[10][1000];
    int dataIndex=0;
    int formatIndex=0;
    int textIndex=0;
    title="";subtitle="";source="";
    
    String[] seriesType = new String[10];
    String[] seriesFill = new String[10];
    String[] seriesBorder= new String[10];
             
    float valmax=0, valmin=0, valstep=0;
    float valmax2=0, valmin2=0, valstep2=0;
    boolean valmaxSet=false, valminSet=false, valstepSet=false;
    boolean valmax2Set=false, valmin2Set=false, valstep2Set=false;
    
    String valTitle="", valTitle2="";
    boolean valShowTitle=false, valShowTitle2=false;
    
    int chartWidth =410 , chartHeight=320;
    float barWidth = 0.75f;
    int plotX1=0, plotY1=0, plotX2=0, plotY2=0;
    boolean plotX1Set=false, plotY1Set=false, plotX2Set=false, plotY2Set=false;
    String styleMode="";
    
    boolean showTitle=false;
    boolean showSubtitle=false;
    boolean showLegend=false;
    boolean showSource=false;
    int chartAreaColor = 0xffF9F9F9;
    int plotAreaColor = 0xffFFFFFF;
    int gridLineColor = 0xffCCCCCC;
    int plotBorderColor= 0xffCCCCCC;
    
    String titleFontName = "Gill Sans MT";
    float titleFontSize = 18;
    String subtitleFontName = "Gill Sans MT Italic";
    float subtitleFontSize = 14;
    String labelFontName = "Arial Narrow";
    float labelFontSize=12;
    
    boolean ticks = false;
    boolean between = true;
    boolean tilted = false;
    int interval=1;
    boolean reSize = true;
    boolean horizontal = true;
    
    String colorStyle = "DISCRETE";
    
    for (int i = 0; i < dataFile.length; i++){
      if ((trim(dataFile[i]).length() == 0)||(dataFile[i].startsWith("#"))) {
        continue; 
      }
      String[] components = split(dataFile[i], ":");
      if (components.length>2){
        for (int j=0; j<components.length-1;j++){
          if (components[j].charAt(components[j].length()-1)=='\\') {
            components[j]=components[j].substring(components[j].length()-1)+":"+components[j+1]; 
            for (int k=j+1; k<components.length-1;k++){
              components[k]=components[k+1];
            }
          }
        }
      }
      components[0]=trim(components[0].toLowerCase());
      
      if (components[0].equals("title"))          {title=components[1];if(title.length()>0){showTitle=true;}} 
      else if (components[0].equals("subtitle"))  {subtitle=components[1];if(subtitle.length()>0){showSubtitle=true;}}
      else if (components[0].equals("source"))    {source=components[1];if(source.length()>0){showSource=true;}}
      else if (components[0].equals("labels"))    {myLabels=split(components[1], TAB);}

      else if (components[0].equals("valmax"))    {valmax  =PApplet.parseFloat(components[1]);valmaxSet=true;}
      else if (components[0].equals("valmin"))    {valmin  =PApplet.parseFloat(components[1]);valminSet=true;}
      else if (components[0].equals("valstep"))   {valstep =PApplet.parseFloat(components[1]);valstepSet=true;}
      else if (components[0].equals("valmax2"))   {valmax2 =PApplet.parseFloat(components[1]);has2Axes=true;valmax2Set=true;}
      else if (components[0].equals("valmin2"))   {valmin2 =PApplet.parseFloat(components[1]);has2Axes=true;valmin2Set=true;}
      else if (components[0].equals("valstep2"))  {valstep2=PApplet.parseFloat(components[1]);has2Axes=true;valstep2Set=true;}

      else if (components[0].equals("valtitle"))  {valTitle=components[1];valShowTitle=true;}
      else if (components[0].equals("valtitle2")) {subtitle=components[1];valShowTitle2=true;}
      
      else if (components[0].equals("valaxis"))   {
        String[] valaxis=split(components[1],TAB);
        if (valaxis.length>2)
        valmax=PApplet.parseFloat(valaxis[0]);valmaxSet=true;
        valmin=PApplet.parseFloat(valaxis[1]);valminSet=true;
        valstep=PApplet.parseFloat(valaxis[2]);valstepSet=true;
        if (valaxis.length>3)
        valTitle=valaxis[3];
        valShowTitle=true;
      }
      else if (components[0].equals("valaxis2"))   {
        has2Axes=true;
        String[] valaxis=split(components[1],TAB);
        if (valaxis.length>2)
        valmax2=PApplet.parseFloat(valaxis[0]);valmax2Set=true;
        valmin2=PApplet.parseFloat(valaxis[1]);valmin2Set=true;
        valstep2=PApplet.parseFloat(valaxis[2]);valstep2Set=true;
        if (valaxis.length>3)
        valTitle2=valaxis[3];
        valShowTitle2=true;
      }
      else if (components[0].equals("titlefont"))       {titleFontName =components[1];}
      else if (components[0].equals("titlefontsize"))   {titleFontSize =PApplet.parseInt(components[1]);}
      else if (components[0].equals("subtitlefont"))    {subtitleFontName =components[1];}
      else if (components[0].equals("subtitlefontsize")){subtitleFontSize =PApplet.parseInt(components[1]);}
      else if (components[0].equals("labelfont"))       {labelFontName =components[1];}
      else if (components[0].equals("labelfontsize"))   {labelFontSize =PApplet.parseInt(components[1]);}
      
      else if (components[0].equals("between"))   {between = PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("ticks"))     {ticks = PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("tilted"))    {tilted = PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("interval"))  {interval = PApplet.parseInt(components[1]);}
      
      else if (components[0].equals("width"))     {chartWidth =PApplet.parseInt(components[1]);}
      else if (components[0].equals("height"))    {chartHeight=PApplet.parseInt(components[1]);}
      else if (components[0].equals("barwidth"))  {barWidth   =PApplet.parseFloat(components[1]);}
      
      else if (components[0].equals("chartarea")) {chartAreaColor=unhex(components[1]);}
      else if (components[0].equals("plotarea"))  {plotAreaColor=unhex(components[1]);}
      else if (components[0].equals("gridline"))  {gridLineColor=unhex(components[1]);}      
      else if (components[0].equals("plotborder")){plotBorderColor=unhex(components[1]);}
      
      else if (components[0].equals("x1"))     {plotX1 =PApplet.parseInt(components[1]);plotX1Set=true;}
      else if (components[0].equals("x2"))     {plotX2 =PApplet.parseInt(components[1]);plotX2Set=true;}
      else if (components[0].equals("y1"))     {plotY1 =PApplet.parseInt(components[1]);plotY1Set=true;}
      else if (components[0].equals("y2"))     {plotY2 =PApplet.parseInt(components[1]);plotY2Set=true;}
      
      else if (components[0].equals("mode"))     {styleMode =components[1];}
      else if (components[0].equals("colormode")){colorStyle=components[1];}
      else if (components[0].equals("resize"))   {reSize=PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("horizontal")){horizontal=PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("showtitle")){showTitle=PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("showsubtitle")){showSubtitle=PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("showlegend")){showLegend=PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("showsource")){showSource=PApplet.parseBoolean(components[1]);}
      else if (components[0].equals("text")){
        String[] myText = split(components[1],TAB);
        label[textIndex]=myText[0];
        labelX[textIndex]=PApplet.parseFloat(myText[1]);
        labelY[textIndex]=PApplet.parseFloat(myText[2]);
        textIndex++;
      }
      else if (components[0].equals("format")){
        String[] myFormat = split(components[1],TAB);
        seriesType[formatIndex]=myFormat[0];
        if (seriesType[formatIndex].equals("LINE")||seriesType[formatIndex].equals("AREA")||seriesType[formatIndex].equals("SAREA")){
          between=false;
          ticks=true;
        }
        if (myFormat.length>1) {
          seriesFill[formatIndex]=(myFormat[1]);
          if (myFormat.length>2) {
            seriesBorder[formatIndex]=(myFormat[2]);
          } else {
            colorMode(HSB);
            seriesBorder[formatIndex]=hex(color(hue(unhex(seriesFill[formatIndex])), saturation(unhex(seriesFill[formatIndex])), .5f*brightness(unhex(seriesFill[formatIndex]))));
            colorMode(RGB);
          }            
        } else {seriesFill[formatIndex]="";seriesBorder[formatIndex]="";}
        formatIndex++;
      }
      else if (components[0].equals("data"))      {
        String[] mySeries=split(components[1],TAB);
        for (int j=0;j<mySeries.length;j++){
          myValues[dataIndex][j]=PApplet.parseFloat(mySeries[j]);
        }
        dataIndex++;
      }
      else if (components[0].equals("series"))    {
        mySeriesNames=split(components[1], TAB);
        for (int j=0;j<mySeriesNames.length;j++){
          if (mySeriesNames[j].length()>0){showLegend=true;}
        }
      }
      
    } 
    
    if (styleMode.length()>0) {
      style=new ChartStyle(styleMode);
      if(debug) {println("Using pre-defined style: "+styleMode);}
      if (plotX1Set){style.plotX1=plotX1;}
      if (plotX2Set){style.plotX2=plotX2;}
      if (plotY1Set){style.plotY1=plotY1;}
      if (plotY2Set){style.plotY2=plotY2;}
      style.showTitle=showTitle;
      style.showSubtitle=showSubtitle;
      style.showLegend=showLegend;
      style.showSource=showSource;
    } else {
      if (!plotX1Set){plotX1=5;}
      if (!plotX2Set){plotX2=chartWidth-5;}
      if (!plotY1Set){plotY1=5;}
      if (!plotY2Set){plotY2=chartHeight-5;}
      style=new ChartStyle(chartWidth, chartHeight, titleFontName, titleFontSize, subtitleFontName, subtitleFontSize, showTitle, showSubtitle, showLegend, showSource, horizontal, barWidth, plotAreaColor, chartAreaColor, gridLineColor, plotBorderColor, plotX1, plotX2, plotY1, plotY2);
      if(debug) {println("Constructing style. "+chartWidth+" "+chartHeight+" "+titleFontName+" "+titleFontSize+" "+subtitleFontName+" "+subtitleFontSize+" "+showTitle+" "+showSubtitle+" "+showLegend+" "+showSource+" "+horizontal+" "+barWidth+" "+plotAreaColor+" "+chartAreaColor+" "+gridLineColor+" "+plotBorderColor+" "+plotX1+" "+plotX2+" "+plotY1+" "+plotY2);}
    }
    for(int i=0;i<dataIndex;i++){
      if(debug) {println("Building series "+i);}
      series[i]= new Series(myValues[i],mySeriesNames[i],i);
    }
    seriesNb=dataIndex;
    labelNb = textIndex;
    dimAxis = new DimAxis(myLabels, labelFontName, labelFontSize);
    if (tilted) {dimAxis.style.angle = PI/6;}
    dimAxis.style.tick = ticks;
    dimAxis.style.between = between;
    dimAxis.style.interval = interval;
    if(debug) {println("Nb Values:"+dimAxis.nbValues);}
    valAxis = new ValAxis(myValues, labelFontName, labelFontSize);
    if (valShowTitle){valAxis.title=valTitle;valAxis.hasTitle=true;}
    if (valmaxSet){valAxis.maxVal=valmax;}
    if (valminSet){valAxis.minVal=valmin;}
    if (valstepSet){valAxis.step=valstep;}
    if (has2Axes){
      valAxis2= new ValAxis(myValues, labelFontName, labelFontSize);
      if (valShowTitle2){valAxis2.title=valTitle2;valAxis2.hasTitle=true;}
      if (valmax2Set){valAxis2.maxVal=valmax2;}
      if (valmin2Set){valAxis2.minVal=valmin2;}
      if (valstep2Set){valAxis2.step=valstep2;}
    }
    
    if (colorStyle.equals("GRADIENT")) {reColor("GRADIENT");} else {reColor("DISCRETE");}
    
    for (int i=0;i<formatIndex;i++){
      series[i].style.type=seriesType[i];
      if(seriesFill[i].length()>0){
        if (seriesFill[i].length()==6){seriesFill[i]="FF"+seriesFill[i];}
        if (seriesBorder[i].length()==6){seriesBorder[i]="FF"+seriesBorder[i];}
        series[i].style.seriesFill=unhex(seriesFill[i]);
        series[i].style.seriesBorder=unhex(seriesBorder[i]);
      }
      if(debug){println("Style of series "+i+": "+series[i].style.type+" "+series[i].style.seriesFill+" "+series[i].style.seriesBorder);}
  }
    
    if (reSize){style.updateSize(this);}
  }  
    
  
  public void reColor(String mode){
    int[] stone = {0xff1f77b4, 0xffff7f0e, 0xff2ca02c, 0xffd62728, 0xff9667bd, 0xff8c564b, 0xffe377c2, 0xff7f7f7f, 0xffbcbd22, 0xff17becf};
    if (mode.equals("DISCRETE")) {
      colorMode(RGB);
      for(int i=0;i<seriesNb;i++){series[i].style.seriesFill=stone[i];}
    } else if (mode.equals("GRADIENT")){
      colorMode(HSB);
      float hue0=hue(series[0].style.seriesFill);
      float sat0=saturation(series[0].style.seriesFill);
      float bri0=brightness(series[0].style.seriesFill);
      for(int i=1;i<seriesNb;i++){series[i].style.seriesFill=color(hue0,map(i,0, seriesNb,sat0,(sat0<96?sat0:96)),map(i,0,seriesNb,bri0,(bri0>224?bri0:224)));}
    }
    colorMode(HSB);
    for(int i=0;i<seriesNb;i++){series[i].style.seriesBorder=color(hue(series[i].style.seriesFill), saturation(series[i].style.seriesFill), .5f*brightness(series[i].style.seriesFill));}
    colorMode(RGB);
  }

  public void display(){
    boolean debug = false;
    
    float plotX1=style.plotX1, plotX2=style.plotX2, plotY1=style.plotY1, plotY2=style.plotY2;
    int nbValues = dimAxis.nbValues;
    boolean horizontal = style.horizontal;
    
    
    // 0. Calculation of dimensions & finetuning
    // ---------------------------------------------------------------------------------------------------------------------------------------------------------  
    

    
    rectMode(CORNERS);
    size(style.chartWidth, style.chartHeight);
    
    // 0.a useful measures for the rest of the procedure

    float slotWidth, barWidth;
    if (horizontal){
      slotWidth = ((plotX2-plotX1))/(nbValues-(dimAxis.style.between?0:1));
      barWidth = (slotWidth*style.barWidth)/seriesNb;
      if (debug) {println((plotX2-plotX1)+" "+nbValues+" "+slotWidth);}
    } 
    else {
      slotWidth = (plotY2-plotY1)/(nbValues-(dimAxis.style.between?0:1));
      barWidth = (slotWidth*style.barWidth)/seriesNb;
    }
    if (debug) {println("slotWidth: "+slotWidth);println("barWidth: "+barWidth);}
  
    
    
    //
    // 1. Before plotting values
    // ---------------------------------------------------------------------------------------------------------------------------------------------------------
    
    
    /// 1.a plot area

    stroke(style.plotBorderColor);
    fill(style.plotAreaColor);
    rect(plotX1,plotY1,plotX2,plotY2);
    
    /// 1.b  gridlines

    if(horizontal){
      for(float i=valAxis.minVal;i<=valAxis.maxVal;i+=valAxis.step){
        float labelY = map(i,valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
        stroke(style.gridLineColor);
        line(plotX1,labelY,plotX2,labelY);        
      }
    }
    else {
      for(float i=valAxis.minVal;i<=valAxis.maxVal;i+=valAxis.step){
        float labelX = map(i,valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
        stroke(style.gridLineColor);
        line(labelX,plotY1,labelX,plotY2);        
      }
    }
    
    //   
    // 2. series    
    // ---------------------------------------------------------------------------------------------------------------------------------------------------------
    
    for (int i=0;i<seriesNb;i++) {
      if (series[i].style.type.equals("BAR")) {
        for (int j=0;j<nbValues;j++){
          float rectX1, rectX2, rectY1, rectY2;
          stroke(series[i].style.seriesBorder);
          fill(series[i].style.seriesFill);
          if (horizontal){
            rectX1 = plotX1+(j+.5f*(1-style.barWidth))*slotWidth+i*barWidth;
            rectX2 = rectX1+barWidth-1;
            rectY1 = map(series[i].values[j], valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
            rectY2 = map(0,valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
          } 
          else {
            rectX1 = map(0, valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
            rectX2 = map(series[i].values[j], valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
            rectY1 = plotY1+(j+.5f*(1-style.barWidth))*slotWidth+i*barWidth;
            rectY2 = rectY1+barWidth-1;
          }
          if (debug)  {println("rectangle "+j+": "+rectX1+" "+rectX2+" "+rectY1+" "+rectY2);}
          rect(rectX1, rectY1, rectX2,  rectY2);
        }
      }
      if (series[i].style.type.equals("SBAR")) {
        for (int j=0;j<nbValues;j++){
          float rectX1, rectX2, rectY1, rectY2;
          float val=0;
          for (int k=0;k<i;k++){val+=series[k].values[j];}
          stroke(series[i].style.seriesBorder);
          fill(series[i].style.seriesFill);
          if (horizontal){
            rectX1 = plotX1+(j+.5f*(1-style.barWidth))*slotWidth;
            rectX2 = rectX1+slotWidth*style.barWidth-1;
            rectY1 = map(series[i].values[j]+val, valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
            rectY2 = map(val,valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
          } 
          else {
            rectX1 = map(val, valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
            rectX2 = map(series[i].values[j]+val, valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
            rectY1 = plotY1+(j+.5f*(1-style.barWidth))*slotWidth;
            rectY2 = rectY1+slotWidth*style.barWidth-1;
          }
          if (debug)  {println("rectangle "+j+": "+rectX1+" "+rectX2+" "+rectY1+" "+rectY2);}
          rect(rectX1, rectY1, rectX2,  rectY2);
        }
      }
      if (series[i].style.type.equals("LINE")) {
        stroke(series[i].style.seriesFill);
        strokeWeight(2);
        smooth();
        noFill();
        beginShape();
        for (int j=0;j<nbValues;j++){
          float lineX1, lineY1;
          if (horizontal){
            lineX1 = plotX1+j*slotWidth + (dimAxis.style.between?barWidth/2:0);
            if (lineX1<=plotX1){lineX1++;}else if(lineX1>=plotX2){lineX1--;}
            lineY1 = map(series[i].values[j], valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
          } 
          else {
            lineX1 = map(series[i].values[j], valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
            lineY1 = plotY1+(dimAxis.style.between?barWidth/2:0);
            if(lineY1<=plotY1){lineY1++;}else if(lineY1>=plotY2){lineY1--;}
          }
          if (debug)  {println("point "+j+": "+lineX1+" "+lineY1);}
          vertex(lineX1, lineY1);
        }
        endShape();
        strokeWeight(1);
      }
      if (series[i].style.type.equals("DOTS")) {
              fill(series[i].style.seriesFill);
              stroke(series[i].style.seriesBorder);
              strokeWeight(2);
              smooth();
              
              beginShape();
              for (int j=0;j<nbValues;j++){
                float dotX1, dotY1;
                if (horizontal){
                  dotX1 = plotX1+j*slotWidth + (dimAxis.style.between?barWidth/2:0);
                  if(dotX1<=plotX1){dotX1++;}else if(dotX1>=plotX2){dotX1--;}
                  dotY1 = map(series[i].values[j], valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
                } 
                else {
                  dotX1 = map(series[i].values[j], valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
                  dotY1 = plotY1+(dimAxis.style.between?barWidth/2:0);
                  if(dotY1<=plotY1){dotY1++;}else if(dotY1>=plotY2){dotY1--;}
                }
                if (debug)  {println("point "+j+": "+dotX1+" "+dotY1);}
                ellipse(dotX1, dotY1, 5, 5);
              }
              strokeWeight(1);
      }
      if (series[i].style.type.equals("AREA")) {
        float lineX1=0, lineY1=0;
        stroke(series[i].style.seriesBorder);
        strokeWeight(1);
        smooth();
        fill(series[i].style.seriesFill);
        beginShape();
        vertex(plotX1, horizontal?plotY2:plotY1);
        for (int j=0;j<nbValues;j++){
          if (horizontal){
            lineX1 = plotX1+j*slotWidth + (dimAxis.style.between?barWidth/2:0);
            lineY1 = map(series[i].values[j], valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
          } 
          else {
            lineX1 = map(series[i].values[j], valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
            lineY1 = plotY1+(dimAxis.style.between?barWidth/2:0);
          }
          if (debug)  {println("point "+j+": "+lineX1+" "+lineY1);}
          vertex(lineX1, lineY1);
        }
        if (horizontal) {
          vertex(lineX1,plotY2);
        } 
        else {
          vertex(plotX1,lineY1);
        }
        endShape(CLOSE);
        strokeWeight(1);
      }
      if (series[i].style.type.equals("SAREA")) {
        float lineX1=0, lineY1=0;
        stroke(series[i].style.seriesBorder);
        strokeWeight(1);
        smooth();
        fill(series[i].style.seriesFill);
        beginShape();
        vertex(plotX1, horizontal?plotY2:plotY1);
        for (int j=0;j<nbValues;j++){
          float val=0;
          for (int k=0;k<i;k++){
            val+=series[k].values[j];
          }  
          if (horizontal){
            lineX1 = plotX1+j*slotWidth + (dimAxis.style.between?barWidth/2:0);
            lineY1 = map(series[i].values[j]+val, valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
          } 
          else {
            lineX1 = map(series[i].values[j]+val, valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
            lineY1 = plotY1+(dimAxis.style.between?barWidth/2:0);
          }
          if (debug)  {println("point "+j+": "+lineX1+" "+lineY1);}
          vertex(lineX1, lineY1);
        }
        for (int j=nbValues-1;j>=0;j--){
          float val=0;
          for (int k=0;k<i;k++){
            val+=series[k].values[j];
          }  
          if (horizontal){
            lineX1 = plotX1+j*slotWidth + (dimAxis.style.between?barWidth/2:0);
            lineY1 = map(val, valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
          } 
          else {
            lineX1 = map(val, valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
            lineY1 = plotY1+(dimAxis.style.between?barWidth/2:0);
          }
          if (debug)  {println("point "+j+": "+lineX1+" "+lineY1);}
          vertex(lineX1, lineY1);
        }
        endShape(CLOSE);
        strokeWeight(1);
      }
    }
    
    
    
    // 3. After series
    // ---------------------------------------------------------------------------------------------------------------------------------------------------------
    
    
    /// 3.a background
    
    fill(style.chartAreaColor);noStroke();
   
    rect(0,0,width,plotY1+1);                         // =======
    rect(0,plotY1,plotX1+1,plotY2);       // |
    rect(plotX2, plotY1,width,plotY2);    //       |
    rect(0,plotY2,width, height);                     // =======
    
      
    /// 3.b title
    
    fill(0);
    textFont(style.titleFont);
    textAlign(CENTER,TOP);
    float heightTitle=0;
    if (style.showTitle){
      text(title,style.chartWidth/2,style.chartHeight*.02f);
      heightTitle += textAscent()+textDescent();
      heightTitle += (style.chartHeight*.02f>7?style.chartHeight*.02f:7);
    }
    if (style.showSubtitle){
      textFont(style.subtitleFont);
      text(subtitle, style.chartWidth/2, heightTitle);
      heightTitle += textAscent()+textDescent();
    }
    
    /// 3.c legend 
    
    if (style.showLegend){
      textFont(style.subtitleFont);
      float legendWidth=0;
      float currentX=0;
     
      if (style.showSubtitle==false){/*heightTitle+=10;*/}
      for (int i=0;i<seriesNb;i++){
        if (series[i].name.length()>0){
          legendWidth+=style.chartWidth*.1f+textWidth(series[i].name);
        }
      }
      currentX=(style.chartWidth-legendWidth)/2;
      for (int i=0;i<seriesNb;i++){
        if (series[i].name.length()>0){
          textAlign(LEFT,TOP);
          stroke(series[i].style.seriesBorder);
          fill(series[i].style.seriesFill);
          rect(currentX, heightTitle, currentX+style.chartWidth*.05f, heightTitle+textAscent()+textDescent());
          currentX+=style.chartWidth*.075f;
          fill(0);
          text(series[i].name, currentX, heightTitle);
          currentX+=textWidth(series[i].name)+style.chartWidth*.025f;
        }
      }
    }
    

    
    /// 3.d  values

    textFont(valAxis.font);
    if(horizontal){
      textAlign(RIGHT);
      for(float i=valAxis.minVal;i<=valAxis.maxVal;i+=valAxis.step){
        if(i==valAxis.minVal){
          textAlign(RIGHT,BOTTOM);
        }
        else if(i>valAxis.maxVal-valAxis.step){
          textAlign(RIGHT,TOP);
        }
        else{
          textAlign(RIGHT,CENTER);
        }       
        float labelY = map(i,valAxis.minVal, valAxis.maxVal, plotY2, plotY1);
        stroke(0);
        fill(0);
        line(plotX1, labelY, plotX1+2,labelY);
        text(nfs(i,0,0), plotX1-5, labelY);
      }
      if (valAxis.hasTitle) {textAlign(RIGHT,BOTTOM);pushMatrix();translate(plotX1-textWidth(nfs(valAxis.maxVal,0,0))-5, plotY1);rotate(3*PI/2);text(valAxis.title,0,0);popMatrix();} 
      if (has2Axes){
        stroke(0);
        line(plotX2, plotY1, plotX2, plotY2);
        for(float i=valAxis2.minVal;i<=valAxis2.maxVal;i+=valAxis2.step){
          if(i==valAxis2.minVal){
            textAlign(LEFT,BOTTOM);
          }
          else if(i>valAxis2.maxVal-valAxis2.step){
            textAlign(LEFT,TOP);
          }
          else{
            textAlign(LEFT,CENTER);
          }       
          float labelY = map(i,valAxis2.minVal, valAxis2.maxVal, plotY2, plotY1);
          stroke(0);
          fill(0);
          line(plotX2, labelY, plotX2-2,labelY);
          text(nfs(i,0,0), plotX2+5, labelY);
        }
        if (valAxis2.hasTitle) {textAlign(RIGHT,TOP);pushMatrix();translate(plotX2+textWidth(nfs(valAxis2.maxVal,0,0))+5, plotY1);rotate(3*PI/2);text(valAxis2.title,0,0);popMatrix();} 
      }
    }
    else {
      textAlign(CENTER,TOP);
      for(float i=valAxis.minVal;i<=valAxis.maxVal;i+=valAxis.step){
        float labelX = map(i,valAxis.minVal, valAxis.maxVal, plotX1, plotX2);
        stroke(0);
        fill(0);
        line(labelX, plotY2, labelX, plotY2-2);
        text(nfs(i,0,0), labelX, plotY2+5);
      }
    }

    /// 3.e dimensions
    
    //// 3.e.1 this is where we write the category labels

    textFont(dimAxis.font);
    if (horizontal){
      for(int i=0;i<nbValues;i+=dimAxis.style.interval){
        float labelX;
        textAlign(CENTER,TOP);
        if(dimAxis.style.between==false) {if(i==0){textAlign(LEFT,TOP);} else if(i==nbValues-dimAxis.style.interval){textAlign(RIGHT,TOP);}}
        if(dimAxis.style.angle!=0){textAlign(RIGHT,TOP);}
        labelX=plotX1+(i+(dimAxis.style.between?.5f:0))*slotWidth;
        pushMatrix();
        translate(labelX-sin(dimAxis.style.angle)*(textAscent()+textDescent()), plotY2+(style.chartHeight/64));
        if (debug)  {println("translated from "+labelX+"/"+(plotY2+10.0f));}
        rotate(-dimAxis.style.angle);
        text(dimAxis.labels[i],0,0);
        popMatrix();
        if(dimAxis.style.tick){stroke(0);line(labelX,plotY2,labelX,plotY2+2);} 
      }
    } 
    else {
      for(int i=0;i<nbValues;i+=dimAxis.style.interval){
        textAlign(LEFT,CENTER);
        if (i==0){textAlign(LEFT,TOP);}else if(i>=nbValues+dimAxis.style.interval){textAlign(LEFT,BOTTOM);}
        float labelY=plotY1+(i+.5f)*slotWidth;
        text(dimAxis.labels[i],5,labelY);
        if(dimAxis.style.tick){stroke(0);line(plotX2-2,labelY,plotX2,labelY);}
      }
    }
    
    // 3.f source
    
    if (style.showSource&&(!source.equals(""))) {
      textFont(style.subtitleFont);
      textAlign(RIGHT,BOTTOM);
      text(source,width-5,height-5);
    }     
    
    // 3.g additional text
    textFont(dimAxis.font);textAlign(LEFT,BOTTOM);
    for (int i=0;i<labelNb;i++){text(label[i],labelX[i],labelY[i]);}

  
    // 4. axes
    // ---------------------------------------------------------------------------------------------------------------------------------------------------------
    
    stroke(0);
    line(plotX1,plotY1, plotX1, plotY2);
    line(plotX1,plotY2, plotX2, plotY2);
    if (horizontal){
      line(plotX1,map(0,valAxis.minVal, valAxis.maxVal, plotY2, plotY1), plotX2, map(0,valAxis.minVal, valAxis.maxVal, plotY2, plotY1));
    }
    else {
      line(map(0,valAxis.minVal, valAxis.maxVal, plotX1, plotX2), plotY1, map(0,valAxis.minVal, valAxis.maxVal, plotX1, plotX2), plotY2);
    }
  }
}

class Series{
  float[] values = new float[1000];
  int nbValues;
  SeriesStyle style;
  String name;
  boolean mainAxis =true;

  Series(float[] myValues, int seriesId){
    arraycopy(myValues,values);
    nbValues = myValues.length;
    style = new SeriesStyle(seriesId);
    name = "Series " + seriesId;
  }

  Series(float[] myValues, String myName, int seriesId){
    arraycopy(myValues,values);
    nbValues = myValues.length;
    name = myName;
    style = new SeriesStyle(seriesId);
  }

  Series(float[] myValues, String myName, String myType, int seriesId){
    arraycopy(myValues,values);
    nbValues = myValues.length;
    name = myName;
    style = new SeriesStyle(myType, seriesId);
  }

}




class ChartStyle{
  int chartWidth, chartHeight;
  PFont titleFont;
  PFont subtitleFont;
  int chartAreaColor = 0xffF9F9F9;
  int plotAreaColor = 0xffFFFFFF;
  int gridLineColor = 0xffCCCCCC;
  int plotBorderColor= 0xffCCCCCC;
  boolean showTitle = true;
  boolean showSubtitle = false;
  boolean showLegend = false;
  boolean showSource = true;
  boolean horizontal = true;
  int plotX1, plotX2, plotY1, plotY2;
  float barWidth = 0.75f;
   
  ChartStyle(String mode){
   if (mode.equals("LARGE")){
      chartWidth = 800;
      chartHeight = 600;
      titleFont = createFont("Gill Sans MT", 48, true);
      subtitleFont = createFont("Gill Sans MT Italic", 32, true);
      //titleFont = loadFont("FrutigerLinotype-Bold-13.vlw");
      //subtitleFont = loadFont("FrutigerLinotype-Roman-12.vlw");
      showSubtitle = true;
      showLegend= true;
  }
    
    if (mode.equals("DEFAULT")){
      chartWidth = 410;
      chartHeight = 320;
      titleFont = createFont("Gill Sans MT", 18, true);
      subtitleFont = createFont("Gill Sans MT Italic", 14, true);
      //titleFont = loadFont("FrutigerLinotype-Bold-13.vlw");
      //subtitleFont = loadFont("FrutigerLinotype-Roman-12.vlw");
      showSubtitle = true;
      showLegend= true;
  }
    if (mode.equals("SMALL")) {
      chartWidth = /*300;*/ 250;
      chartHeight = /*200;*/ 180;
      titleFont=createFont("Gill Sans MT", 10, true);
      subtitleFont = createFont("Verdana", 8, true);
    }
    if (mode.equals("COMITEM")) {
      chartWidth = 130;
      chartHeight = 250;
      titleFont=createFont("Verdana", 7, true);
      subtitleFont = createFont("Verdana", 7, true);
      showSubtitle=false;
      horizontal=false;
    }
      plotX1=5;plotY1=5;
      plotX2=chartWidth-5;plotY2=chartHeight-5;
    }
      
  ChartStyle(int myChartWidth, int myChartHeight, String titleFontName, float titleFontSize, String subtitleFontName, float subtitleFontSize, boolean myShowTitle, boolean myShowSubtitle, boolean myShowLegend, boolean myShowSource, boolean myHorizontal, float myBarWidth,  int myPlotAreaColor, int myChartAreaColor, int myGridLineColor, int myPlotBorderColor, int myPlotX1, int myPlotX2, int myPlotY1, int myPlotY2){
    chartWidth=myChartWidth;
    chartHeight=myChartHeight;
    titleFont=createFont(titleFontName, titleFontSize, true);
    subtitleFont=createFont(subtitleFontName, subtitleFontSize, true);
    showTitle=myShowTitle;
    showSubtitle=myShowSubtitle;
    showLegend=myShowLegend;
    showSource=myShowSource;
    horizontal=myHorizontal;
    barWidth=myBarWidth;
    chartAreaColor = myChartAreaColor;
    plotAreaColor = myPlotAreaColor;
    gridLineColor = myGridLineColor;
    plotBorderColor= myPlotBorderColor;
    plotX1=max(myPlotX1,0);
    plotX2=min(myPlotX2,chartWidth);
    plotY1=max(myPlotY1,0);
    plotY2=min(myPlotY2,chartHeight);
}
  
  public void updateSize(Chart myChart){
    boolean debug=false;
    DimAxis myDimAxis = myChart.dimAxis;
    ValAxis myValAxis = myChart.valAxis;
    
    float labelGap = chartWidth*.03f;
    float dimGap = chartHeight*.03f;
    float titleGap = chartHeight*.02f;
    
    float headerSize=0;
    float footerSize=0;
    float leftMargin=0;
    float rightMargin=0;
    if (debug){println("original dimensions:"+plotX1+" "+plotX2+" "+plotY1+" "+plotY2);}
    /*
    1. X-size
    */
        
    textFont(myValAxis.font);
    leftMargin = labelGap+textWidth(nfs(max(abs(myValAxis.maxVal),abs(myValAxis.minVal)),0,0));
    if (myValAxis.hasTitle) {leftMargin+=textAscent()+textDescent();}
    
    rightMargin= labelGap;
    if (myChart.has2Axes){
      rightMargin+=textWidth(nfs(max(abs(myChart.valAxis2.maxVal),abs(myChart.valAxis2.minVal)),0,0));
      if (myChart.valAxis2.hasTitle) {rightMargin+=textAscent()+textDescent();}
    }
    
    if (plotX1<leftMargin){plotX1=PApplet.parseInt(leftMargin);}
    if (plotX2>myChart.style.chartWidth-rightMargin){plotX2=PApplet.parseInt(myChart.style.chartWidth-rightMargin);}
    
    if (plotX1<labelGap+textWidth(nfs(max(abs(myValAxis.maxVal),abs(myValAxis.minVal)),0,0))) {
        plotX1 = PApplet.parseInt(labelGap + textWidth(nfs(max(abs(myValAxis.maxVal),abs(myValAxis.minVal)),0,0)));
    }
    
    /*
     2. Y size
    */
    textFont(titleFont);
    if (showTitle) {headerSize+=textAscent()+textDescent()+chartHeight*.02f;}
    textFont(subtitleFont);
    if (showSubtitle) {
      headerSize+=textAscent()+textDescent()/*+max(chartHeight*.02,7)*/;
    }
    if (showLegend){
      headerSize+=textAscent()+textDescent()/*+10*/;}  
    if (plotY1<titleGap+headerSize) {plotY1=PApplet.parseInt(titleGap+headerSize);}
    
    textFont(myDimAxis.font);
    footerSize+=dimGap+textAscent()+textDescent();
    if (!(myChart.source.equals("")||showSource==false)){
      textFont(subtitleFont);
      footerSize+=textAscent()+textDescent();
    }
    
   if (plotY2>chartHeight-footerSize){plotY2=PApplet.parseInt(chartHeight-footerSize);}
   
   // extra adjustment if dimension labels written at an angle. This only applies to horizontal type charts.
   // this may affect plotX1 and plotY2.
   
   if(horizontal){
      if (myChart.dimAxis.style.angle!=0) {
        float maxW=0, h=0, s=0;
        float slotWidth; 
        slotWidth = PApplet.parseFloat((plotX2-plotX1))/(myDimAxis.nbValues-(myDimAxis.style.between?0:1));
        textFont(subtitleFont);
        s=(showSource?textAscent()+textDescent():0);
        textFont(myChart.dimAxis.font);
        h=textAscent()+textDescent();
        for(int i=0;i<myDimAxis.nbValues;i+=myDimAxis.style.interval){
          maxW=(textWidth(myDimAxis.labels[i])>maxW)?textWidth(myDimAxis.labels[i]):maxW;
          if (plotX1+(i+(myDimAxis.style.between?.5f:0))*slotWidth-cos(myDimAxis.style.angle)*textWidth(myDimAxis.labels[i])-sin(myDimAxis.style.angle)*h<0){
            plotX1=PApplet.parseInt(-(i+(myDimAxis.style.between?.5f:0))*slotWidth+cos(myDimAxis.style.angle)*textWidth(myDimAxis.labels[i])+sin(myDimAxis.style.angle)*h);
          }
        }
        if(plotY2+sin(myDimAxis.style.angle)*maxW+cos(myDimAxis.style.angle)*h+(chartHeight/64)+s>chartHeight) {
          plotY2=PApplet.parseInt(chartHeight-s-sin(myDimAxis.style.angle)*maxW-cos(myDimAxis.style.angle)*h-(chartHeight/64));
        }
      }
    }
    if (debug) {println("redefining dimensions: "+plotX1+" "+plotX2+" "+plotY1+" "+plotY2);}
  }
  
  public void reSize(int newWidth, int newHeight){
      int titleFontSize, subtitleFontSize, paddingSize;
      chartWidth = newWidth;
      chartHeight = newHeight;
      titleFontSize=PApplet.parseInt(sqrt(chartWidth*chartHeight)/28);
      subtitleFontSize=PApplet.parseInt(titleFontSize*.7f);
      paddingSize=PApplet.parseInt(chartWidth*chartHeight/25000);
      titleFont=createFont("Verdana bold",  titleFontSize,true);
      subtitleFont = createFont("Verdana", subtitleFontSize,true);
    
      plotX1=plotY1=paddingSize;
      plotX2=chartWidth-paddingSize;plotY2=chartHeight-paddingSize;}
}



class SeriesStyle {
  String type="BAR";
  int seriesFill = 0xffB8CCE4;
  int seriesBorder = 0xff376091;
  
  SeriesStyle(){}
  SeriesStyle(String myType){
    type=myType;}
  SeriesStyle(String myType, int myFill, int myBorder){
    type=myType;
    seriesFill=myFill;
    seriesBorder=myBorder;}
 // for the 2 following constructors, the colors should depend on the series Id.
   SeriesStyle(int seriesId){
     int[] stone = {0xff1f77b4, 0xffff7f0e, 0xff2ca02c, 0xffd62728, 0xff9667bd, 0xff8c564b, 0xffe377c2, 0xff7f7f7f, 0xffbcbd22, 0xff17becf};
     seriesFill = stone[seriesId];
     colorMode(HSB);
     seriesBorder = color(hue(seriesFill),saturation(seriesFill),.5f*brightness(seriesFill));
     colorMode(RGB);
   }

   SeriesStyle(String myType, int seriesId){
     int[] stone = {0xff1f77b4, 0xffff7f0e, 0xff2ca02c, 0xffd62728, 0xff9667bd, 0xff8c564b, 0xffe377c2, 0xff7f7f7f, 0xffbcbd22, 0xff17becf};
     seriesFill = stone[seriesId];
     colorMode(HSB);
     seriesBorder = color(hue(seriesFill),saturation(seriesFill),.5f*brightness(seriesFill));
     colorMode(RGB);   
     type=myType;
   }
}

class AxisStyle{
    boolean between = true;
    int interval =1;
    float angle = 0;
    boolean tick = true; 
    AxisStyle(){}
    AxisStyle(boolean myBol){between=myBol;}
    AxisStyle(boolean myBol1, boolean myBol2){between=myBol1;tick=myBol2;}
  }

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#e0dfe3", "plotter" });
  }
}
